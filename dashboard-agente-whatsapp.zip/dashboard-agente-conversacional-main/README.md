# Dashboard Agente Conversacional

Dashboard para agentes conversacionales con IA. Interfaz de chat moderna con soporte para múltiples conversaciones, persistencia en base de datos, y arquitectura lista para producción.

## Features

- **Chat con IA** - Interfaz conversacional fluida con streaming de respuestas
- **Múltiples conversaciones** - Gestión de historial y contexto por conversación
- **Autenticación** - Sistema de auth completo con Supabase
- **Dashboard de analytics** - Visualización de métricas de uso
- **Clasificación de mensajes** - Categorización automática de intenciones
- **Arquitectura Feature-First** - Código organizado para escalabilidad

## Tech Stack

```yaml
Framework: Next.js 16 (App Router + Turbopack)
Runtime: React 19 + TypeScript
Database: Supabase (PostgreSQL)
Auth: Supabase Auth
Styling: Tailwind CSS
AI: Vercel AI SDK + OpenRouter
```

## Estructura del Proyecto

```
src/
├── app/
│   ├── (auth)/           # Login, Signup, Reset password
│   ├── (main)/           # Dashboard principal
│   ├── admin/            # Panel de administración
│   └── api/
│       ├── agent/        # Endpoint del agente IA
│       ├── analytics/    # Métricas de uso
│       ├── chat/         # Streaming de chat
│       ├── classify/     # Clasificación de intenciones
│       └── conversations/ # CRUD de conversaciones
│
├── features/
│   ├── auth/             # Autenticación
│   ├── chat/             # Chat con IA
│   └── dashboard/        # Dashboard y analytics
│
└── shared/
    ├── components/       # UI components (Button, Input, etc.)
    ├── hooks/            # Hooks reutilizables
    ├── lib/              # Supabase client, utils
    └── types/            # Tipos compartidos
```

## Quick Start

### 1. Clonar e instalar

```bash
git clone https://github.com/tu-usuario/dashboard-agente-conversacional.git
cd dashboard-agente-conversacional
npm install
```

### 2. Variables de entorno

```bash
cp .env.local.example .env.local
```

Configura las siguientes variables:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=tu_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_anon_key

# OpenRouter (para IA)
OPENROUTER_API_KEY=tu_api_key
```

### 3. Iniciar desarrollo

```bash
npm run dev
```

La app estará disponible en `http://localhost:3000`

## API Endpoints

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `/api/chat` | POST | Streaming de chat con IA |
| `/api/agent` | POST | Agente conversacional |
| `/api/conversations` | GET/POST | Gestión de conversaciones |
| `/api/classify` | POST | Clasificación de intenciones |
| `/api/analytics` | GET | Métricas de uso |

## Comandos

```bash
npm run dev      # Desarrollo con Turbopack
npm run build    # Build de producción
npm run start    # Servidor de producción
npm run lint     # Linting con ESLint
```

## Arquitectura

### Feature-First

Cada feature contiene todo lo necesario para funcionar de forma independiente:

```
features/chat/
├── components/   # ChatWindow, MessageBubble, MessageInput
├── hooks/        # useChat, useConversations
├── services/     # chatService.ts
├── types/        # Message, Conversation, etc.
└── store/        # Estado local del chat
```

### Flujo de Chat

```
Usuario → MessageInput → /api/chat → OpenRouter → Streaming → ChatWindow
                              ↓
                        Supabase (persistencia)
```

## Supabase Setup

### Tablas requeridas

```sql
-- Conversaciones
create table conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  title text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Mensajes
create table messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references conversations(id) on delete cascade,
  role text check (role in ('user', 'assistant', 'system')),
  content text,
  created_at timestamptz default now()
);

-- RLS policies
alter table conversations enable row level security;
alter table messages enable row level security;

create policy "Users can manage own conversations"
  on conversations for all
  using (auth.uid() = user_id);

create policy "Users can manage messages in own conversations"
  on messages for all
  using (conversation_id in (
    select id from conversations where user_id = auth.uid()
  ));
```

## Personalización

### Cambiar modelo de IA

En `/api/chat/route.ts`:

```typescript
const response = await openai.chat.completions.create({
  model: 'anthropic/claude-3-opus', // Cambiar modelo aquí
  // ...
});
```

### Agregar nuevas intenciones

En `/api/classify/route.ts`, modifica el prompt de clasificación para incluir nuevas categorías.

## Deploy

### Vercel (recomendado)

```bash
npm install -g vercel
vercel
```

Configura las variables de entorno en el dashboard de Vercel.

### Docker

```bash
docker build -t dashboard-agente .
docker run -p 3000:3000 dashboard-agente
```

## Desarrollo con IA

Este proyecto está optimizado para desarrollo asistido por IA:

- **CLAUDE.md** - Instrucciones completas para Claude Code
- **Arquitectura Feature-First** - Contexto completo por carpeta
- **MCPs integrados** - Next.js DevTools, Playwright, Supabase

## Licencia

MIT

---

Built with Next.js 16 + Supabase + AI
