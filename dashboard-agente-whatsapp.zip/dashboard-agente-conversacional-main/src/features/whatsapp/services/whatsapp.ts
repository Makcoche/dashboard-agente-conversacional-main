import { createHmac, timingSafeEqual } from 'node:crypto'

const GRAPH_VERSION = process.env.WHATSAPP_GRAPH_VERSION || 'v21.0'
const MAX_LEN = 4000 // límite real de WhatsApp: 4096

/** Valida X-Hub-Signature-256 sobre el cuerpo CRUDO. */
export function verifySignature(rawBody: string, header: string | null): boolean {
  const secret = process.env.WHATSAPP_APP_SECRET
  if (!secret || !header?.startsWith('sha256=')) return false

  const expected = createHmac('sha256', secret).update(rawBody).digest('hex')
  const received = header.slice('sha256='.length)

  const a = Buffer.from(expected, 'hex')
  const b = Buffer.from(received, 'hex')
  return a.length === b.length && timingSafeEqual(a, b)
}

/** Convierte el Markdown típico de LLM al formato de WhatsApp. */
export function toWhatsAppFormat(text: string): string {
  return text
    .replace(/^#{1,6}\s+(.+)$/gm, '*$1*') // títulos -> negrita
    .replace(/\*\*(.+?)\*\*/g, '*$1*') // **negrita** -> *negrita*
    .replace(/__(.+?)__/g, '_$1_')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '$1: $2') // [t](url) -> t: url
}

/** Divide en trozos <= MAX_LEN cortando en saltos de párrafo/línea/espacio. */
export function splitMessage(text: string, max = MAX_LEN): string[] {
  const parts: string[] = []
  let rest = text.trim()

  while (rest.length > max) {
    let cut = rest.lastIndexOf('\n\n', max)
    if (cut < max / 2) cut = rest.lastIndexOf('\n', max)
    if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
    if (cut < max / 2) cut = max
    parts.push(rest.slice(0, cut).trim())
    rest = rest.slice(cut).trim()
  }
  if (rest) parts.push(rest)
  return parts
}

async function graphPost(body: Record<string, unknown>) {
  const token = process.env.WHATSAPP_TOKEN
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID
  if (!token || !phoneId) throw new Error('WHATSAPP_TOKEN / WHATSAPP_PHONE_NUMBER_ID no configurados')

  const res = await fetch(`https://graph.facebook.com/${GRAPH_VERSION}/${phoneId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', ...body }),
  })

  if (!res.ok) throw new Error(`WhatsApp API ${res.status}: ${await res.text()}`)
  return res.json()
}

export async function sendText(to: string, text: string) {
  for (const chunk of splitMessage(toWhatsAppFormat(text))) {
    await graphPost({ to, type: 'text', text: { body: chunk, preview_url: false } })
  }
}

/** Marca como leído (doble check azul). No crítico: no lanza errores. */
export async function markAsRead(messageId: string) {
  try {
    await graphPost({ status: 'read', message_id: messageId })
  } catch (err) {
    console.warn('markAsRead falló:', err)
  }
}

// --- Tipos mínimos del payload del webhook ---
export interface WaMessage {
  id: string
  from: string
  timestamp: string
  type: string
  text?: { body: string }
}

export interface WaWebhookPayload {
  object?: string
  entry?: Array<{
    changes?: Array<{
      value?: {
        metadata?: { phone_number_id?: string }
        contacts?: Array<{ wa_id: string; profile?: { name?: string } }>
        messages?: WaMessage[]
        statuses?: unknown[]
      }
    }>
  }>
}
