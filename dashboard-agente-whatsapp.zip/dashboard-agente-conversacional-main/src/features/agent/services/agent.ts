import type { SupabaseClient } from '@supabase/supabase-js'

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'
const HISTORY_LIMIT = 10

export interface AgentConfig {
  id: string
  name: string
  system_prompt: string
  model_id: string
  temperature: number
  max_tokens: number
}

export async function getActiveAgent(supabase: SupabaseClient): Promise<AgentConfig> {
  const { data, error } = await supabase
    .from('agents')
    .select('id, name, system_prompt, model_id, temperature, max_tokens')
    .eq('is_active', true)
    .single()

  if (error || !data) throw new Error('No hay un agente activo')
  return data as AgentConfig
}

/**
 * Últimos N mensajes en orden cronológico.
 * (Se pide desc + limit y luego se invierte: con asc + limit se obtendrían
 * los PRIMEROS N, y el agente perdería el contexto reciente.)
 */
export async function getHistory(
  supabase: SupabaseClient,
  conversationId: string,
  limit = HISTORY_LIMIT
): Promise<Array<{ role: 'user' | 'assistant'; content: string }>> {
  const { data } = await supabase
    .from('messages')
    .select('role, content')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .limit(limit)

  return ((data ?? []) as Array<{ role: 'user' | 'assistant'; content: string }>).reverse()
}

/** Llamada al LLM SIN streaming (WhatsApp envía el texto completo). */
export async function generateReply(
  agent: AgentConfig,
  history: Array<{ role: 'user' | 'assistant'; content: string }>,
  extraSystem?: string
): Promise<{ text: string; tokens?: number }> {
  const apiKey = process.env.OPENROUTER_API_KEY
  if (!apiKey) throw new Error('OPENROUTER_API_KEY no configurada')

  const system = extraSystem ? `${agent.system_prompt}\n\n${extraSystem}` : agent.system_prompt

  const res = await fetch(OPENROUTER_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
      'X-Title': 'SaaS Factory Agent',
    },
    body: JSON.stringify({
      model: agent.model_id,
      messages: [{ role: 'system', content: system }, ...history],
      temperature: agent.temperature,
      max_tokens: agent.max_tokens,
    }),
  })

  if (!res.ok) throw new Error(`OpenRouter ${res.status}: ${await res.text()}`)

  const json = await res.json()
  const text: string | undefined = json.choices?.[0]?.message?.content
  if (!text?.trim()) throw new Error('Respuesta vacía del LLM')

  return { text: text.trim(), tokens: json.usage?.total_tokens }
}
