'use client'

import type { ChatMessage } from '../types'
import { TypingIndicator } from './TypingIndicator'

interface MessageBubbleProps {
  message: ChatMessage
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === 'user'
  const isStreaming = message.isStreaming && message.content === ''

  return (
    <div
      className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-3`}
    >
      <div
        className={`
          max-w-[80%] rounded-2xl px-4 py-3
          ${isUser
            ? 'bg-white/10 text-white border border-white/10'
            : 'bg-white/5 text-white/90 border border-white/5'
          }
          backdrop-blur-sm
        `}
      >
        {isStreaming ? (
          <TypingIndicator />
        ) : (
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {message.content}
          </p>
        )}
      </div>
    </div>
  )
}
