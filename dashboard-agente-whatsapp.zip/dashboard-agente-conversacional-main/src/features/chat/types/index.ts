// ============================================
// Chat Types - Tipos para el sistema de chat
// ============================================

export type MessageRole = 'user' | 'assistant' | 'system'

export interface ChatMessage {
  id: string
  role: MessageRole
  content: string
  timestamp: Date
  isStreaming?: boolean
}

export interface ChatState {
  messages: ChatMessage[]
  isLoading: boolean
  isStreaming: boolean
  error: string | null
  conversationId: string | null
}

export interface SendMessageParams {
  content: string
  visitorId: string
  conversationId?: string
  visitorMetadata?: Record<string, unknown>
}

export interface ChatConfig {
  agentName: string
  agentAvatar?: string
  systemPrompt: string
  modelId: string
  temperature: number
  maxTokens: number
}

export interface StreamChunk {
  type: 'content' | 'done' | 'error' | 'meta'
  content?: string
  error?: string
  conversationId?: string
}
