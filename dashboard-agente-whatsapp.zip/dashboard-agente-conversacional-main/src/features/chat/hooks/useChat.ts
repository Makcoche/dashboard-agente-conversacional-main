'use client'

import { useState, useCallback, useRef, useEffect } from 'react'
import type { ChatMessage, ChatState, StreamChunk } from '../types'

function generateId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
}

function getVisitorId(): string {
  if (typeof window === 'undefined') return 'server'

  let visitorId = localStorage.getItem('visitor_id')
  if (!visitorId) {
    visitorId = `visitor_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
    localStorage.setItem('visitor_id', visitorId)
  }
  return visitorId
}

export function useChat() {
  const [state, setState] = useState<ChatState>({
    messages: [],
    isLoading: false,
    isStreaming: false,
    error: null,
    conversationId: null,
  })

  const abortControllerRef = useRef<AbortController | null>(null)
  const messagesEndRef = useRef<HTMLDivElement | null>(null)

  // Auto-scroll cuando hay nuevos mensajes
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [state.messages])

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim() || state.isLoading) return

    // Cancelar request anterior si existe
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }
    abortControllerRef.current = new AbortController()

    const userMessage: ChatMessage = {
      id: generateId(),
      role: 'user',
      content: content.trim(),
      timestamp: new Date(),
    }

    const assistantMessage: ChatMessage = {
      id: generateId(),
      role: 'assistant',
      content: '',
      timestamp: new Date(),
      isStreaming: true,
    }

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage, assistantMessage],
      isLoading: true,
      isStreaming: true,
      error: null,
    }))

    try {
      const visitorId = getVisitorId()

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: content.trim(),
          visitorId,
          conversationId: state.conversationId,
        }),
        signal: abortControllerRef.current.signal,
      })

      if (!response.ok) {
        throw new Error(`HTTP error: ${response.status}`)
      }

      const reader = response.body?.getReader()
      if (!reader) {
        throw new Error('No response body')
      }

      const decoder = new TextDecoder()
      let buffer = ''
      let fullContent = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (!line.trim()) continue

          try {
            const chunk: StreamChunk = JSON.parse(line)

            // Manejar meta con conversationId
            if (chunk.type === 'meta' && chunk.conversationId) {
              setState(prev => ({
                ...prev,
                conversationId: chunk.conversationId!,
              }))
            }

            if (chunk.type === 'content' && chunk.content) {
              fullContent += chunk.content

              setState(prev => ({
                ...prev,
                messages: prev.messages.map(m =>
                  m.id === assistantMessage.id
                    ? { ...m, content: fullContent }
                    : m
                ),
              }))
            }

            if (chunk.type === 'done') {
              setState(prev => ({
                ...prev,
                messages: prev.messages.map(m =>
                  m.id === assistantMessage.id
                    ? { ...m, isStreaming: false }
                    : m
                ),
                isLoading: false,
                isStreaming: false,
              }))
            }

            if (chunk.type === 'error') {
              throw new Error(chunk.error || 'Unknown error')
            }
          } catch (parseError) {
            // Ignorar errores de parsing (pueden ser líneas vacías)
            console.debug('Parse error:', parseError)
          }
        }
      }

    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        // Request fue cancelado, no es un error real
        return
      }

      console.error('Chat error:', error)

      setState(prev => ({
        ...prev,
        messages: prev.messages.filter(m => m.id !== assistantMessage.id),
        isLoading: false,
        isStreaming: false,
        error: error instanceof Error ? error.message : 'Error al enviar mensaje',
      }))
    }
  }, [state.isLoading, state.conversationId])

  const clearMessages = useCallback(() => {
    setState({
      messages: [],
      isLoading: false,
      isStreaming: false,
      error: null,
      conversationId: null,
    })
  }, [])

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }))
  }, [])

  return {
    messages: state.messages,
    isLoading: state.isLoading,
    isStreaming: state.isStreaming,
    error: state.error,
    conversationId: state.conversationId,
    sendMessage,
    clearMessages,
    clearError,
    messagesEndRef,
  }
}
