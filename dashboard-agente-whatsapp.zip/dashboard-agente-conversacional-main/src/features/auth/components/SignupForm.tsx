'use client'

import { useState } from 'react'
import { signup } from '../services/auth'

export function SignupForm() {
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function handleSubmit(formData: FormData) {
    setLoading(true)
    setError(null)

    const result = await signup(formData)

    if (result?.error) {
      setError(result.error)
      setLoading(false)
    }
  }

  return (
    <form action={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="email" className="block text-sm font-medium text-white/80 mb-2">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          required
          autoComplete="email"
          className="
            w-full px-4 py-3
            bg-white/5 hover:bg-white/10 focus:bg-white/10
            backdrop-blur-md
            border border-white/10 focus:border-white/30
            rounded-xl
            text-white placeholder-white/40
            outline-none
            transition-all duration-300
          "
          placeholder="tu@email.com"
        />
      </div>

      <div>
        <label htmlFor="password" className="block text-sm font-medium text-white/80 mb-2">
          Password
        </label>
        <input
          id="password"
          name="password"
          type="password"
          required
          minLength={6}
          autoComplete="new-password"
          className="
            w-full px-4 py-3
            bg-white/5 hover:bg-white/10 focus:bg-white/10
            backdrop-blur-md
            border border-white/10 focus:border-white/30
            rounded-xl
            text-white placeholder-white/40
            outline-none
            transition-all duration-300
          "
          placeholder="Min. 6 characters"
        />
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 backdrop-blur-sm">
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="
          w-full py-3 px-4
          bg-white/10 hover:bg-white/20
          backdrop-blur-xl
          border border-white/20
          rounded-xl
          text-white font-medium
          shadow-lg shadow-black/20
          transition-all duration-300
          hover:shadow-xl hover:scale-[1.02]
          disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100
        "
      >
        {loading ? 'Creating account...' : 'Create Account'}
      </button>
    </form>
  )
}
