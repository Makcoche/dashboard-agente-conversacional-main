import { createClient } from '@supabase/supabase-js'

/**
 * Cliente con service role: salta RLS. SOLO para código de servidor sin sesión
 * de usuario (webhooks). Nunca importar desde componentes cliente.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) {
    throw new Error('NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY no configuradas')
  }
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } })
}
