import { NextRequest, NextResponse, after } from 'next/server'
import type { SupabaseClient } from '@supabase/supabase-js'
import { createAdminClient } from '@/shared/lib/supabase/admin'
import { getActiveAgent, getHistory, generateReply } from '@/features/agent/services/agent'
import {
  verifySignature,
  sendText,
  markAsRead,
  type WaMessage,
  type WaWebhookPayload,
} from '@/features/whatsapp/services/whatsapp'

export const runtime = 'nodejs'
export const maxDuration = 60 // segundos (Vercel)

const WHATSAPP_STYLE_HINT =
  'Estás respondiendo por WhatsApp. Sé breve y conversacional. ' +
  'No uses Markdown, tablas ni encabezados; si necesitas énfasis usa *negrita* de WhatsApp. ' +
  'Usa listas simples con guiones.'

const FALLBACK_ERROR = 'Disculpa, tuve un problema procesando tu mensaje. ¿Puedes intentarlo de nuevo en un momento?'
const FALLBACK_UNSUPPORTED = 'Por ahora solo puedo leer mensajes de texto. ¿Puedes escribirme tu consulta?'

// GET: verificación inicial del webhook por parte de Meta
export async function GET(request: NextRequest) {
  const p = request.nextUrl.searchParams
  const mode = p.get('hub.mode')
  const token = p.get('hub.verify_token')
  const challenge = p.get('hub.challenge')

  if (mode === 'subscribe' && token && token === process.env.WHATSAPP_VERIFY_TOKEN && challenge) {
    return new Response(challenge, { status: 200 })
  }
  return new Response('Forbidden', { status: 403 })
}

// POST: mensajes entrantes
export async function POST(request: NextRequest) {
  const raw = await request.text()

  if (!verifySignature(raw, request.headers.get('x-hub-signature-256'))) {
    return new Response('Invalid signature', { status: 401 })
  }

  let payload: WaWebhookPayload
  try {
    payload = JSON.parse(raw)
  } catch {
    return new Response('Bad request', { status: 400 })
  }

  // Responder 200 de inmediato; Meta reintenta si tardamos. Procesar después.
  after(async () => {
    for (const entry of payload.entry ?? []) {
      for (const change of entry.changes ?? []) {
        const value = change.value
        if (!value?.messages?.length) continue // statuses (entregado/leído) se ignoran

        // Solo atender el número configurado
        const expectedId = process.env.WHATSAPP_PHONE_NUMBER_ID
        if (expectedId && value.metadata?.phone_number_id !== expectedId) continue

        for (const msg of value.messages) {
          const name = value.contacts?.find((c) => c.wa_id === msg.from)?.profile?.name
          try {
            await handleMessage(msg, name)
          } catch (err) {
            console.error('WhatsApp handleMessage error:', err)
            try {
              await sendText(msg.from, FALLBACK_ERROR)
            } catch (sendErr) {
              console.error('No se pudo enviar el mensaje de error:', sendErr)
            }
          }
        }
      }
    }
  })

  return NextResponse.json({ received: true })
}

async function handleMessage(msg: WaMessage, contactName?: string) {
  if (msg.type !== 'text' || !msg.text?.body?.trim()) {
    await sendText(msg.from, FALLBACK_UNSUPPORTED)
    return
  }

  const supabase = createAdminClient()
  const agent = await getActiveAgent(supabase)
  const conversationId = await getOrCreateConversation(supabase, agent.id, msg.from, contactName)

  // Guardar mensaje del usuario; si el wamid ya existe es un reintento de Meta
  const { error: insertError } = await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'user',
    content: msg.text.body,
    external_id: msg.id,
  })
  if (insertError) {
    if (insertError.code === '23505') return // duplicado
    throw insertError
  }

  void markAsRead(msg.id)

  const start = Date.now()
  const history = await getHistory(supabase, conversationId)
  const reply = await generateReply(agent, history, WHATSAPP_STYLE_HINT)

  await sendText(msg.from, reply.text)

  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role: 'assistant',
    content: reply.text,
    model_used: agent.model_id,
    tokens_used: reply.tokens,
    processing_time_ms: Date.now() - start,
  })
}

async function getOrCreateConversation(
  supabase: SupabaseClient,
  agentId: string,
  phone: string,
  contactName?: string
): Promise<string> {
  const visitorId = `wa_${phone}`

  const find = () =>
    supabase
      .from('conversations')
      .select('id')
      .eq('agent_id', agentId)
      .eq('visitor_id', visitorId)
      .maybeSingle()

  const { data: existing } = await find()
  if (existing) return existing.id

  const { data, error } = await supabase
    .from('conversations')
    .insert({ agent_id: agentId, visitor_id: visitorId, channel: 'whatsapp', contact_name: contactName ?? null })
    .select('id')
    .single()

  if (error) {
    // Carrera: otro mensaje la creó entre el select y el insert
    if (error.code === '23505') {
      const { data: again } = await find()
      if (again) return again.id
    }
    throw error
  }
  return data.id
}
