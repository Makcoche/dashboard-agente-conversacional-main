import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/shared/lib/supabase/server'

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'
const CLASSIFICATION_MODEL = 'google/gemini-2.0-flash-001'
const SESSION_GAP_HOURS = 4

interface ClassificationResult {
  topics: string[]
  intent: 'learning' | 'troubleshooting' | 'exploration' | 'onboarding' | 'feedback'
  quality: 'high' | 'medium' | 'low' | 'spam'
  summary: string
  flags: {
    frustration_detected: boolean
    escalation_needed: boolean
    bug_reported: boolean
    resolved: boolean
  }
}

function buildClassificationPrompt(transcript: string, topics: string[]): string {
  return `Analiza la siguiente conversación y responde ÚNICAMENTE con JSON válido (sin markdown, sin explicaciones):

{
  "topics": [array de topics de la lista permitida],
  "intent": "learning|troubleshooting|exploration|onboarding|feedback",
  "quality": "high|medium|low|spam",
  "summary": "Resumen de 1-2 oraciones en español",
  "flags": {
    "frustration_detected": boolean (si el usuario mostró frustración),
    "escalation_needed": boolean (si necesita atención humana),
    "bug_reported": boolean (si reportó un bug/error),
    "resolved": boolean (si se resolvió su consulta)
  }
}

TOPICS DISPONIBLES: ${JSON.stringify(topics)}

CONVERSACIÓN:
${transcript}

Responde SOLO el JSON, nada más:`
}

async function classifyTranscript(
  transcript: string,
  topics: string[],
  apiKey: string
): Promise<ClassificationResult> {
  const response = await fetch(OPENROUTER_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
      'X-Title': 'SaaS Factory Classifier',
    },
    body: JSON.stringify({
      model: CLASSIFICATION_MODEL,
      messages: [
        {
          role: 'user',
          content: buildClassificationPrompt(transcript, topics),
        },
      ],
      temperature: 0.1,
      max_tokens: 500,
    }),
  })

  if (!response.ok) {
    throw new Error('Classification API failed')
  }

  const data = await response.json()
  const content = data.choices?.[0]?.message?.content || '{}'

  // Limpiar el contenido de posibles wrappers de markdown
  const cleanContent = content
    .replace(/```json\n?/g, '')
    .replace(/```\n?/g, '')
    .trim()

  return JSON.parse(cleanContent)
}

// POST: Clasificar sesiones pendientes
export async function POST(request: NextRequest) {
  try {
    const apiKey = process.env.OPENROUTER_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        { error: 'OPENROUTER_API_KEY not configured' },
        { status: 500 }
      )
    }

    const supabase = await createClient()

    // Verificar que el usuario es admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Obtener agente activo
    const { data: agent } = await supabase
      .from('agents')
      .select('id, classification_topics')
      .eq('is_active', true)
      .single()

    if (!agent) {
      return NextResponse.json({ error: 'No active agent found' }, { status: 404 })
    }

    const topics = agent.classification_topics as string[]

    // Crear/actualizar sesiones basadas en gap de 4 horas
    // Primero, obtener todas las conversaciones con mensajes
    const { data: conversations } = await supabase
      .from('conversations')
      .select(`
        id,
        agent_id,
        messages (
          id,
          role,
          content,
          created_at
        )
      `)
      .eq('agent_id', agent.id)
      .order('created_at', { ascending: true })

    if (!conversations || conversations.length === 0) {
      return NextResponse.json({ message: 'No conversations to process', processed: 0 })
    }

    let sessionsCreated = 0
    let sessionsClassified = 0

    for (const conv of conversations) {
      const messages = (conv.messages as Array<{
        id: string
        role: string
        content: string
        created_at: string
      }>).sort(
        (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      )

      if (messages.length === 0) continue

      // Agrupar mensajes en sesiones por gap de 4 horas
      const sessions: Array<{
        messages: typeof messages
        firstMessageAt: Date
        lastMessageAt: Date
      }> = []

      let currentSession: typeof messages = []
      let lastMessageTime: Date | null = null

      for (const msg of messages) {
        const msgTime = new Date(msg.created_at)

        if (
          lastMessageTime &&
          msgTime.getTime() - lastMessageTime.getTime() > SESSION_GAP_HOURS * 60 * 60 * 1000
        ) {
          // Gap mayor a 4 horas, nueva sesión
          if (currentSession.length > 0) {
            sessions.push({
              messages: currentSession,
              firstMessageAt: new Date(currentSession[0].created_at),
              lastMessageAt: new Date(currentSession[currentSession.length - 1].created_at),
            })
          }
          currentSession = []
        }

        currentSession.push(msg)
        lastMessageTime = msgTime
      }

      // Agregar última sesión
      if (currentSession.length > 0) {
        sessions.push({
          messages: currentSession,
          firstMessageAt: new Date(currentSession[0].created_at),
          lastMessageAt: new Date(currentSession[currentSession.length - 1].created_at),
        })
      }

      // Procesar cada sesión
      for (const session of sessions) {
        const transcript = session.messages
          .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
          .join('\n\n')

        const userMsgCount = session.messages.filter((m) => m.role === 'user').length
        const assistantMsgCount = session.messages.filter((m) => m.role === 'assistant').length

        // Verificar si ya existe esta sesión
        const { data: existingSession } = await supabase
          .from('conversation_sessions')
          .select('id, classification')
          .eq('conversation_id', conv.id)
          .eq('first_message_at', session.firstMessageAt.toISOString())
          .single()

        if (existingSession) {
          // Si ya está clasificada, saltar
          if (existingSession.classification) continue

          // Clasificar
          try {
            const classification = await classifyTranscript(transcript, topics, apiKey)

            await supabase
              .from('conversation_sessions')
              .update({
                classification,
                classified_at: new Date().toISOString(),
                classified_by_model: CLASSIFICATION_MODEL,
                last_message_at: session.lastMessageAt.toISOString(),
                message_count: session.messages.length,
                user_message_count: userMsgCount,
                assistant_message_count: assistantMsgCount,
                transcript,
              })
              .eq('id', existingSession.id)

            sessionsClassified++
          } catch (err) {
            console.error('Classification error:', err)
          }
        } else {
          // Crear nueva sesión y clasificar
          try {
            const classification = await classifyTranscript(transcript, topics, apiKey)

            await supabase.from('conversation_sessions').insert({
              conversation_id: conv.id,
              agent_id: agent.id,
              first_message_at: session.firstMessageAt.toISOString(),
              last_message_at: session.lastMessageAt.toISOString(),
              message_count: session.messages.length,
              user_message_count: userMsgCount,
              assistant_message_count: assistantMsgCount,
              transcript,
              classification,
              classified_at: new Date().toISOString(),
              classified_by_model: CLASSIFICATION_MODEL,
            })

            sessionsCreated++
            sessionsClassified++
          } catch (err) {
            console.error('Classification error:', err)
            // Crear sin clasificación
            await supabase.from('conversation_sessions').insert({
              conversation_id: conv.id,
              agent_id: agent.id,
              first_message_at: session.firstMessageAt.toISOString(),
              last_message_at: session.lastMessageAt.toISOString(),
              message_count: session.messages.length,
              user_message_count: userMsgCount,
              assistant_message_count: assistantMsgCount,
              transcript,
            })
            sessionsCreated++
          }
        }
      }
    }

    return NextResponse.json({
      message: 'Classification complete',
      sessionsCreated,
      sessionsClassified,
    })
  } catch (error) {
    console.error('Classify API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
