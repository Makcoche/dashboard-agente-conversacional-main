import { NextResponse } from 'next/server'
import { createClient } from '@/shared/lib/supabase/server'

interface ClassificationFlags {
  frustration_detected?: boolean
  escalation_needed?: boolean
  bug_reported?: boolean
  resolved?: boolean
}

interface Classification {
  topics?: string[]
  intent?: string
  quality?: string
  summary?: string
  flags?: ClassificationFlags
}

interface SessionRow {
  id: string
  classification: Classification | null
  message_count: number
  first_message_at: string
  transcript: string | null
}

export async function GET() {
  try {
    const supabase = await createClient()

    // Verificar auth y admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    // Obtener agente activo
    const { data: agent } = await supabase
      .from('agents')
      .select('id, classification_topics')
      .eq('is_active', true)
      .single()

    if (!agent) {
      return NextResponse.json({ error: 'No active agent found' }, { status: 404 })
    }

    // Obtener todas las sesiones
    const { data: sessions } = await supabase
      .from('conversation_sessions')
      .select('id, classification, message_count, first_message_at, transcript')
      .eq('agent_id', agent.id)
      .order('first_message_at', { ascending: false })

    const allSessions = (sessions || []) as SessionRow[]

    // Calcular estadísticas
    const totalSessions = allSessions.length
    const classifiedSessions = allSessions.filter(s => s.classification)
    const totalMessages = allSessions.reduce((sum, s) => sum + (s.message_count || 0), 0)

    // Conteos de flags
    let resolvedCount = 0
    let frustrationCount = 0
    let escalationCount = 0
    let bugCount = 0

    // Distribución de calidad
    const qualityDist = { high: 0, medium: 0, low: 0, spam: 0 }

    // Conteo de topics
    const topicCounts: Record<string, number> = {}

    // Pain points por topic
    const topicStats: Record<string, {
      sessions: number
      frustrated: number
      unresolved: number
      highQuality: number
      totalMessages: number
    }> = {}

    for (const session of classifiedSessions) {
      const c = session.classification
      if (!c) continue

      // Flags
      if (c.flags?.resolved) resolvedCount++
      if (c.flags?.frustration_detected) frustrationCount++
      if (c.flags?.escalation_needed) escalationCount++
      if (c.flags?.bug_reported) bugCount++

      // Calidad
      if (c.quality && c.quality in qualityDist) {
        qualityDist[c.quality as keyof typeof qualityDist]++
      }

      // Topics
      for (const topic of c.topics || []) {
        topicCounts[topic] = (topicCounts[topic] || 0) + 1

        if (!topicStats[topic]) {
          topicStats[topic] = {
            sessions: 0,
            frustrated: 0,
            unresolved: 0,
            highQuality: 0,
            totalMessages: 0,
          }
        }

        topicStats[topic].sessions++
        topicStats[topic].totalMessages += session.message_count || 0

        if (c.flags?.frustration_detected) topicStats[topic].frustrated++
        if (!c.flags?.resolved) topicStats[topic].unresolved++
        if (c.quality === 'high') topicStats[topic].highQuality++
      }
    }

    // Top topics
    const topTopics = Object.entries(topicCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([topic, count]) => ({
        topic,
        count,
        percentage: totalSessions > 0 ? Math.round((count / totalSessions) * 100) : 0,
      }))

    // Pain points (topics con problemas)
    const painPoints = Object.entries(topicStats)
      .map(([topic, stats]) => ({
        topic,
        sessionCount: stats.sessions,
        frustrationRate: stats.sessions > 0 ? Math.round((stats.frustrated / stats.sessions) * 100) : 0,
        unresolvedRate: stats.sessions > 0 ? Math.round((stats.unresolved / stats.sessions) * 100) : 0,
        highQualityRate: stats.sessions > 0 ? Math.round((stats.highQuality / stats.sessions) * 100) : 0,
        avgMessagesPerSession: stats.sessions > 0 ? Math.round(stats.totalMessages / stats.sessions) : 0,
      }))
      .sort((a, b) => b.frustrationRate - a.frustrationRate)

    // Gap Score: (sessions * frustration) / resolution
    // Prioriza topics con muchas sesiones frustrantes y baja resolución
    const contentGaps = painPoints.map(pp => {
      const resolutionRate = 100 - pp.unresolvedRate
      const gapScore = resolutionRate > 0
        ? Math.round((pp.sessionCount * pp.frustrationRate) / resolutionRate)
        : pp.sessionCount * pp.frustrationRate

      let recommendation: 'urgent' | 'recommended' | 'monitor' | 'ok'
      if (gapScore >= 50) recommendation = 'urgent'
      else if (gapScore >= 20) recommendation = 'recommended'
      else if (gapScore >= 10) recommendation = 'monitor'
      else recommendation = 'ok'

      return {
        topic: pp.topic,
        sessionCount: pp.sessionCount,
        frustrationRate: pp.frustrationRate,
        resolutionRate,
        gapScore,
        recommendation,
      }
    }).sort((a, b) => b.gapScore - a.gapScore)

    // Intervention Queue: sesiones que necesitan atención humana
    const interventionQueue = allSessions
      .filter(s => {
        const c = s.classification
        return c?.flags?.escalation_needed ||
               c?.flags?.frustration_detected ||
               c?.flags?.bug_reported
      })
      .slice(0, 10)
      .map(s => {
        const c = s.classification!
        const hoursAgo = Math.round(
          (Date.now() - new Date(s.first_message_at).getTime()) / (1000 * 60 * 60)
        )

        let severity: 'critical' | 'high' | 'medium' = 'medium'
        if (c.flags?.escalation_needed && c.flags?.frustration_detected) severity = 'critical'
        else if (c.flags?.escalation_needed || c.flags?.bug_reported) severity = 'high'

        return {
          id: s.id,
          summary: c.summary || 'Sin resumen',
          severity,
          flags: {
            frustration: c.flags?.frustration_detected || false,
            escalation: c.flags?.escalation_needed || false,
            bug: c.flags?.bug_reported || false,
          },
          hoursAgo,
        }
      })
      .sort((a, b) => {
        const severityOrder = { critical: 0, high: 1, medium: 2 }
        return severityOrder[a.severity] - severityOrder[b.severity]
      })

    // Resolution rate
    const resolutionRate = classifiedSessions.length > 0
      ? Math.round((resolvedCount / classifiedSessions.length) * 100)
      : 0

    return NextResponse.json({
      overview: {
        totalSessions,
        totalMessages,
        classifiedCount: classifiedSessions.length,
        unclassifiedCount: totalSessions - classifiedSessions.length,
        resolutionRate,
      },
      alerts: {
        frustrationCount,
        escalationNeeded: escalationCount,
        bugsReported: bugCount,
      },
      qualityDistribution: qualityDist,
      topTopics,
      painPoints,
      contentGaps,
      interventionQueue,
    })
  } catch (error) {
    console.error('Analytics API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
