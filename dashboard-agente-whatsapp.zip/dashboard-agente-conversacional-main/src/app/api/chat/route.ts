import { NextRequest } from 'next/server'
import { createClient } from '@/shared/lib/supabase/server'

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'
const DEFAULT_AGENT_ID = '54bcdbee-4bd7-4f64-9dfd-0b3cc3adc855'

interface AgentConfig {
  id: string
  name: string
  system_prompt: string
  model_id: string
  temperature: number
  max_tokens: number
}

async function getAgent(supabase: Awaited<ReturnType<typeof createClient>>): Promise<AgentConfig> {
  const { data } = await supabase
    .from('agents')
    .select('id, name, system_prompt, model_id, temperature, max_tokens')
    .eq('is_active', true)
    .single()

  if (data) return data as AgentConfig

  return {
    id: DEFAULT_AGENT_ID,
    name: 'Asistente',
    system_prompt: 'Eres un asistente amigable y útil.',
    model_id: 'google/gemini-2.0-flash-001',
    temperature: 0.7,
    max_tokens: 500,
  }
}

async function getOrCreateConversation(
  supabase: Awaited<ReturnType<typeof createClient>>,
  agentId: string,
  visitorId: string,
  conversationId?: string
): Promise<string> {
  if (conversationId) {
    const { data } = await supabase
      .from('conversations')
      .select('id')
      .eq('id', conversationId)
      .single()

    if (data) return data.id
  }

  const { data, error } = await supabase
    .from('conversations')
    .insert({ agent_id: agentId, visitor_id: visitorId })
    .select('id')
    .single()

  if (error) throw new Error('Failed to create conversation')
  return data.id
}

async function saveMessage(
  supabase: Awaited<ReturnType<typeof createClient>>,
  conversationId: string,
  role: 'user' | 'assistant',
  content: string,
  metadata?: { tokens_used?: number; model_used?: string; processing_time_ms?: number }
) {
  await supabase.from('messages').insert({
    conversation_id: conversationId,
    role,
    content,
    ...metadata,
  })
}

async function getConversationHistory(
  supabase: Awaited<ReturnType<typeof createClient>>,
  conversationId: string,
  limit = 10
) {
  const { data } = await supabase
    .from('messages')
    .select('role, content')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .limit(limit)

  // desc + limit = los N más recientes; se invierte a orden cronológico
  return (data || []).reverse()
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const body = await request.json()
    const { content, visitorId, conversationId: existingConversationId } = body

    if (!content || typeof content !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Content is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      )
    }

    const apiKey = process.env.OPENROUTER_API_KEY
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'OPENROUTER_API_KEY not configured' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    const supabase = await createClient()
    const agent = await getAgent(supabase)
    const finalVisitorId = visitorId || `anon_${Date.now()}`
    const conversationId = await getOrCreateConversation(
      supabase,
      agent.id,
      finalVisitorId,
      existingConversationId
    )

    // Guardar mensaje del usuario
    await saveMessage(supabase, conversationId, 'user', content)

    // Obtener historial
    const history = await getConversationHistory(supabase, conversationId)

    // Construir mensajes para el LLM
    const llmMessages = [
      { role: 'system', content: agent.system_prompt },
      ...history.map((m) => ({ role: m.role, content: m.content })),
    ]

    // Llamar a OpenRouter
    const llmResponse = await fetch(OPENROUTER_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
        'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
        'X-Title': 'SaaS Factory Agent',
      },
      body: JSON.stringify({
        model: agent.model_id,
        messages: llmMessages,
        temperature: agent.temperature,
        max_tokens: agent.max_tokens,
        stream: true,
      }),
    })

    if (!llmResponse.ok) {
      const error = await llmResponse.text()
      console.error('OpenRouter API error:', error)
      return new Response(
        JSON.stringify({ error: 'Failed to get response from LLM' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    const reader = llmResponse.body?.getReader()
    const encoder = new TextEncoder()
    const decoder = new TextDecoder()

    let fullResponse = ''

    const stream = new ReadableStream({
      async start(controller) {
        if (!reader) {
          controller.close()
          return
        }

        // Enviar conversationId al inicio
        controller.enqueue(
          encoder.encode(JSON.stringify({ type: 'meta', conversationId }) + '\n')
        )

        let buffer = ''

        try {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            buffer += decoder.decode(value, { stream: true })
            const lines = buffer.split('\n')
            buffer = lines.pop() || ''

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6).trim()

                if (data === '[DONE]') {
                  // Guardar respuesta completa del asistente
                  const processingTime = Date.now() - startTime
                  await saveMessage(supabase, conversationId, 'assistant', fullResponse, {
                    model_used: agent.model_id,
                    processing_time_ms: processingTime,
                  })

                  controller.enqueue(encoder.encode(JSON.stringify({ type: 'done' }) + '\n'))
                  continue
                }

                if (!data) continue

                try {
                  const parsed = JSON.parse(data)
                  const chunk = parsed.choices?.[0]?.delta?.content
                  if (chunk) {
                    fullResponse += chunk
                    controller.enqueue(
                      encoder.encode(JSON.stringify({ type: 'content', content: chunk }) + '\n')
                    )
                  }
                } catch {
                  // Ignorar líneas que no son JSON válido
                }
              }
            }
          }
        } catch (error) {
          console.error('Stream processing error:', error)
          controller.enqueue(
            encoder.encode(JSON.stringify({ type: 'error', error: 'Stream error' }) + '\n')
          )
        }

        controller.close()
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (error) {
    console.error('Chat API error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
}
