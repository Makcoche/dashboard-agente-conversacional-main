import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/shared/lib/supabase/server'

// GET: Obtener agente activo
export async function GET() {
  try {
    const supabase = await createClient()

    // Verificar auth y admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const { data: agent, error } = await supabase
      .from('agents')
      .select('*')
      .eq('is_active', true)
      .single()

    if (error || !agent) {
      return NextResponse.json({ error: 'No active agent found' }, { status: 404 })
    }

    return NextResponse.json(agent)
  } catch (error) {
    console.error('Agent GET error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// PUT: Actualizar agente
export async function PUT(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Verificar auth y admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single()

    if (profile?.role !== 'admin') {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 })
    }

    const body = await request.json()
    const {
      name,
      description,
      system_prompt,
      model_id,
      temperature,
      max_tokens,
      classification_topics,
    } = body

    // Obtener agente activo
    const { data: currentAgent } = await supabase
      .from('agents')
      .select('id')
      .eq('is_active', true)
      .single()

    if (!currentAgent) {
      return NextResponse.json({ error: 'No active agent found' }, { status: 404 })
    }

    // Actualizar
    const updateData: Record<string, unknown> = {}
    if (name !== undefined) updateData.name = name
    if (description !== undefined) updateData.description = description
    if (system_prompt !== undefined) updateData.system_prompt = system_prompt
    if (model_id !== undefined) updateData.model_id = model_id
    if (temperature !== undefined) updateData.temperature = temperature
    if (max_tokens !== undefined) updateData.max_tokens = max_tokens
    if (classification_topics !== undefined) updateData.classification_topics = classification_topics

    const { data: agent, error } = await supabase
      .from('agents')
      .update(updateData)
      .eq('id', currentAgent.id)
      .select()
      .single()

    if (error) {
      console.error('Agent update error:', error)
      return NextResponse.json({ error: 'Failed to update agent' }, { status: 500 })
    }

    return NextResponse.json(agent)
  } catch (error) {
    console.error('Agent PUT error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
