export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-950 via-neutral-900 to-black relative overflow-hidden">
      {/* Orbes decorativos con glow sutil */}
      <div className="fixed top-20 left-20 w-72 h-72 bg-neutral-800 rounded-full blur-[128px] opacity-30" />
      <div className="fixed top-40 right-40 w-96 h-96 bg-neutral-700 rounded-full blur-[128px] opacity-20" />
      <div className="fixed bottom-20 left-1/2 w-80 h-80 bg-neutral-800 rounded-full blur-[128px] opacity-25" />

      {/* Contenido */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  )
}
