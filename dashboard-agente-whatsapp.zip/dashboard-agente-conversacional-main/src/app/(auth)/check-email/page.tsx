import Link from 'next/link'

export default function CheckEmailPage() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="
        w-full max-w-md
        bg-white/5 backdrop-blur-2xl
        border border-white/10
        rounded-3xl
        shadow-2xl shadow-black/50
        p-8 space-y-8
        relative overflow-hidden
        text-center
      ">
        {/* Highlight superior */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        {/* Icon */}
        <div className="w-16 h-16 mx-auto rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center">
          <svg className="w-8 h-8 text-white/70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        </div>

        <div>
          <h1 className="text-3xl font-bold text-white">Check your email</h1>
          <p className="mt-4 text-white/50">
            We've sent you a confirmation link. Please check your email to complete your registration.
          </p>
        </div>

        <Link
          href="/login"
          className="
            inline-block py-3 px-6
            bg-white/10 hover:bg-white/20
            backdrop-blur-xl
            border border-white/20
            rounded-xl
            text-white/80 hover:text-white font-medium
            transition-all duration-300
          "
        >
          Back to login
        </Link>
      </div>
    </div>
  )
}
