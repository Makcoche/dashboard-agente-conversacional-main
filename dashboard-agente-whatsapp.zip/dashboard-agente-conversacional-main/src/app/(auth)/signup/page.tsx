import Link from 'next/link'
import { SignupForm } from '@/features/auth/components'

export default function SignupPage() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="
        w-full max-w-md
        bg-white/5 backdrop-blur-2xl
        border border-white/10
        rounded-3xl
        shadow-2xl shadow-black/50
        p-8 space-y-8
        relative overflow-hidden
      ">
        {/* Highlight superior */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />

        <div className="text-center">
          <h1 className="text-3xl font-bold text-white">Create account</h1>
          <p className="mt-2 text-white/50">Get started for free</p>
        </div>

        <SignupForm />

        <p className="text-center text-sm text-white/40">
          Already have an account?{' '}
          <Link href="/login" className="text-white/70 hover:text-white transition-colors">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
