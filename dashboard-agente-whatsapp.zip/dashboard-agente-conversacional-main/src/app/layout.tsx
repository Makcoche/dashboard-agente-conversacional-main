import type { Metadata } from 'next'
import { ChatBubble } from '@/features/chat/components'
import './globals.css'

export const metadata: Metadata = {
  title: 'SaaS Factory App',
  description: 'Built with SaaS Factory',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>
        {children}
        <ChatBubble />
      </body>
    </html>
  )
}
