# ESPECIFICACIONES COMPLETAS: Plantilla Universal de Agente Conversacional

> **Objetivo:** Crear una plantilla de agente conversacional que sirva para cualquier negocio, con clasificación automática de conversaciones y analíticas accionables.

---

## 1. VISIÓN DEL PRODUCTO

### 1.1 Problema que Resuelve

Los negocios necesitan:
1. **Atención al cliente 24/7** sin contratar humanos
2. **Entender qué preguntan los usuarios** para mejorar productos/servicios
3. **Detectar problemas temprano** (frustración, bugs, escalaciones)
4. **Priorizar contenido/documentación** basado en demanda real

### 1.2 Propuesta de Valor

Una plantilla plug-and-play que incluye:
- **Agente conversacional** con streaming en tiempo real
- **Clasificación automática** de conversaciones con IA
- **Dashboard de analíticas** con métricas accionables
- **Sistema de alertas** para intervención humana

### 1.3 Principio 20/80

**El 20% que da el 80% de valor:**

| Componente | Valor |
|------------|-------|
| Chat con streaming | UX fluida, respuestas inmediatas |
| Clasificación automática | Entender qué preguntan los usuarios |
| Resolution Rate | Métrica #1 de calidad del agente |
| Gap Score | Priorizar qué contenido crear |
| Intervention Queue | Detectar problemas urgentes |

---

## 2. ARQUITECTURA TÉCNICA

### 2.1 Stack Tecnológico

| Capa | Tecnología | Razón |
|------|------------|-------|
| **Frontend** | Next.js 15 + React 19 | SSR, streaming nativo, App Router |
| **Styling** | Tailwind CSS 3.4 | Utility-first, sin decisiones |
| **Base de Datos** | Supabase (PostgreSQL) | Realtime, RLS, tipos generados |
| **LLM API** | OpenRouter | Multi-modelo (Gemini, Claude, GPT) |
| **Clasificación** | Gemini Flash via OpenRouter | Barato ($0.075/1M tokens), rápido |
| **State** | Zustand | Minimalista, sin boilerplate |

### 2.2 Estructura de Carpetas

```
src/
├── app/
│   ├── page.tsx                    # Landing/Home
│   ├── chat/
│   │   └── page.tsx                # Interfaz de chat
│   ├── admin/
│   │   ├── page.tsx                # Dashboard principal
│   │   ├── conversations/
│   │   │   └── page.tsx            # Lista de conversaciones
│   │   └── analytics/
│   │       └── page.tsx            # Analíticas detalladas
│   └── api/
│       ├── chat/
│       │   └── route.ts            # Endpoint de chat (streaming)
│       ├── conversations/
│       │   ├── route.ts            # CRUD conversaciones
│       │   └── [id]/
│       │       └── route.ts        # Detalle conversación
│       ├── classify/
│       │   └── route.ts            # Clasificar sesiones
│       └── analytics/
│           └── route.ts            # Métricas y stats
│
├── features/
│   ├── chat/
│   │   ├── components/
│   │   │   ├── ChatWindow.tsx      # Ventana principal de chat
│   │   │   ├── MessageBubble.tsx   # Burbuja de mensaje
│   │   │   ├── MessageInput.tsx    # Input de mensaje
│   │   │   └── TypingIndicator.tsx # Indicador "escribiendo..."
│   │   ├── hooks/
│   │   │   ├── useChat.ts          # Hook principal de chat
│   │   │   └── useStream.ts        # Hook de streaming
│   │   ├── services/
│   │   │   └── chatService.ts      # Llamadas a API
│   │   ├── stores/
│   │   │   └── chatStore.ts        # Estado del chat (Zustand)
│   │   └── types/
│   │       └── index.ts            # Tipos de chat
│   │
│   ├── conversations/
│   │   ├── components/
│   │   │   ├── ConversationList.tsx
│   │   │   ├── SessionCard.tsx
│   │   │   └── TranscriptViewer.tsx
│   │   ├── services/
│   │   │   └── conversationService.ts
│   │   └── types/
│   │       └── index.ts
│   │
│   └── analytics/
│       ├── components/
│       │   ├── AnalyticsDashboard.tsx
│       │   ├── StatsCards.tsx
│       │   ├── ResolutionGauge.tsx
│       │   ├── QualityDonut.tsx
│       │   ├── TopicsChart.tsx
│       │   ├── PainPointsTable.tsx
│       │   ├── ContentGaps.tsx
│       │   └── InterventionQueue.tsx
│       ├── services/
│       │   ├── analyticsService.ts
│       │   └── classificationService.ts
│       └── types/
│           └── index.ts
│
├── shared/
│   ├── components/
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Badge.tsx
│   │   └── Spinner.tsx
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts           # Cliente browser
│   │   │   ├── server.ts           # Cliente server
│   │   │   └── admin.ts            # Cliente admin (service role)
│   │   └── openrouter.ts           # Configuración OpenRouter
│   ├── types/
│   │   └── database.types.ts       # Tipos generados de Supabase
│   └── utils/
│       ├── formatters.ts
│       └── validators.ts
│
└── config/
    └── agent.ts                    # Configuración del agente
```

---

## 3. MODELO DE DATOS

### 3.1 Diagrama Entidad-Relación

```
┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
│     agents      │       │  conversations  │       │    messages     │
├─────────────────┤       ├─────────────────┤       ├─────────────────┤
│ id (PK)         │◄──┐   │ id (PK)         │◄──┐   │ id (PK)         │
│ name            │   │   │ agent_id (FK)───┼───┘   │ conversation_id │
│ system_prompt   │   │   │ visitor_id      │       │ role            │
│ model_id        │   │   │ metadata        │       │ content         │
│ topics[]        │   │   │ created_at      │       │ created_at      │
│ is_active       │   │   │ updated_at      │       └────────┬────────┘
│ created_at      │   │   └────────┬────────┘                │
└─────────────────┘   │            │                         │
                      │            │                         │
                      │   ┌────────┴────────┐                │
                      │   │                 │                │
                      │   ▼                 │                │
┌─────────────────┐   │   ┌─────────────────┴───┐            │
│ conversation_   │   │   │                     │            │
│ sessions        │   │   │    (Agrupación      │            │
├─────────────────┤   │   │     por gap 4h)     │            │
│ id (PK)         │   │   │                     │            │
│ conversation_id │───┘   └─────────────────────┘            │
│ agent_id (FK)───┼───────────────────────────────────────────┘
│ first_message   │
│ last_message    │
│ message_count   │
│ transcript      │
│ classification  │ ◄── JSONB con resultado de IA
│ classified_at   │
│ created_at      │
└─────────────────┘
```

### 3.2 Esquema SQL Completo

```sql
-- ============================================
-- TABLA: agents
-- Configuración del agente de IA
-- ============================================
CREATE TABLE agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Identidad
  name VARCHAR(100) NOT NULL,
  description TEXT,
  avatar_url TEXT,

  -- Configuración IA
  system_prompt TEXT NOT NULL,
  model_id VARCHAR(100) NOT NULL DEFAULT 'google/gemini-2.0-flash-001',
  temperature DECIMAL(2,1) DEFAULT 0.7,
  max_tokens INTEGER DEFAULT 500,

  -- Clasificación
  classification_topics JSONB DEFAULT '["general", "soporte", "ventas", "otro"]'::jsonb,

  -- Estado
  is_active BOOLEAN DEFAULT true,

  -- Metadata
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_agents_active ON agents(is_active) WHERE is_active = true;

-- ============================================
-- TABLA: conversations
-- Una conversación = un hilo de mensajes
-- ============================================
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Relaciones
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,

  -- Identificador del visitante (puede ser anónimo)
  visitor_id VARCHAR(100) NOT NULL,

  -- Metadata del visitante (opcional)
  visitor_metadata JSONB DEFAULT '{}'::jsonb,
  -- Ejemplo: { "name": "Juan", "email": "juan@...", "source": "website" }

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_conversations_agent ON conversations(agent_id);
CREATE INDEX idx_conversations_visitor ON conversations(visitor_id);
CREATE INDEX idx_conversations_created ON conversations(created_at DESC);

-- ============================================
-- TABLA: messages
-- Mensajes individuales de la conversación
-- ============================================
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Relación
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,

  -- Contenido
  role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
  content TEXT NOT NULL,

  -- Metadata de respuesta del agente
  tokens_used INTEGER,
  model_used VARCHAR(100),
  processing_time_ms INTEGER,

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_messages_conversation ON messages(conversation_id);
CREATE INDEX idx_messages_created ON messages(conversation_id, created_at);

-- ============================================
-- TABLA: conversation_sessions
-- Sesiones agrupadas para clasificación
-- ============================================
CREATE TABLE conversation_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Relaciones
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,

  -- Metadata de la sesión
  first_message_at TIMESTAMPTZ NOT NULL,
  last_message_at TIMESTAMPTZ NOT NULL,
  message_count INTEGER NOT NULL DEFAULT 0,
  user_message_count INTEGER NOT NULL DEFAULT 0,
  assistant_message_count INTEGER NOT NULL DEFAULT 0,

  -- Transcript completo (para clasificación)
  transcript TEXT,

  -- Clasificación (resultado de IA)
  classification JSONB,
  /*
  Estructura de classification:
  {
    "topics": ["soporte", "ventas"],
    "intent": "troubleshooting",
    "quality": "high",
    "summary": "Usuario preguntó sobre precios y tuvo problemas con el pago",
    "flags": {
      "frustration_detected": false,
      "escalation_needed": false,
      "bug_reported": false,
      "resolved": true
    }
  }
  */

  classified_at TIMESTAMPTZ,
  classified_by_model VARCHAR(100),

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX idx_sessions_agent ON conversation_sessions(agent_id);
CREATE INDEX idx_sessions_conversation ON conversation_sessions(conversation_id);
CREATE INDEX idx_sessions_first_message ON conversation_sessions(first_message_at DESC);
CREATE INDEX idx_sessions_classification ON conversation_sessions USING GIN (classification)
  WHERE classification IS NOT NULL;
CREATE INDEX idx_sessions_unclassified ON conversation_sessions(agent_id)
  WHERE classification IS NULL;

-- Constraint único para upsert
CREATE UNIQUE INDEX idx_sessions_upsert
  ON conversation_sessions(conversation_id, first_message_at);

-- ============================================
-- TRIGGERS: Auto-update updated_at
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER agents_updated_at
  BEFORE UPDATE ON agents
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================
-- VIEWS: Estadísticas pre-calculadas
-- ============================================
CREATE OR REPLACE VIEW conversation_stats AS
SELECT
  agent_id,
  COUNT(*) as total_sessions,
  SUM(message_count) as total_messages,
  COUNT(*) FILTER (WHERE classification IS NOT NULL) as classified_count,
  COUNT(*) FILTER (WHERE classification IS NULL) as unclassified_count,
  COUNT(*) FILTER (WHERE classification->'flags'->>'resolved' = 'true') as resolved_count,
  COUNT(*) FILTER (WHERE classification->'flags'->>'frustration_detected' = 'true') as frustration_count,
  COUNT(*) FILTER (WHERE classification->'flags'->>'escalation_needed' = 'true') as escalation_count,
  COUNT(*) FILTER (WHERE classification->'flags'->>'bug_reported' = 'true') as bug_count
FROM conversation_sessions
GROUP BY agent_id;
```

### 3.3 Tipos TypeScript

```typescript
// ============================================
// types/database.types.ts
// ============================================

// Enums
export type MessageRole = 'user' | 'assistant' | 'system';
export type ConversationIntent = 'learning' | 'troubleshooting' | 'exploration' | 'onboarding' | 'feedback';
export type ConversationQuality = 'high' | 'medium' | 'low' | 'spam';

// Entidades base
export interface Agent {
  id: string;
  name: string;
  description: string | null;
  avatar_url: string | null;
  system_prompt: string;
  model_id: string;
  temperature: number;
  max_tokens: number;
  classification_topics: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  agent_id: string;
  visitor_id: string;
  visitor_metadata: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: MessageRole;
  content: string;
  tokens_used: number | null;
  model_used: string | null;
  processing_time_ms: number | null;
  created_at: string;
}

// Clasificación
export interface ConversationFlags {
  frustration_detected: boolean;
  escalation_needed: boolean;
  bug_reported: boolean;
  resolved: boolean;
}

export interface ConversationClassification {
  topics: string[];
  intent: ConversationIntent;
  quality: ConversationQuality;
  summary: string;
  flags: ConversationFlags;
}

export interface ConversationSession {
  id: string;
  conversation_id: string;
  agent_id: string;
  first_message_at: string;
  last_message_at: string;
  message_count: number;
  user_message_count: number;
  assistant_message_count: number;
  transcript: string | null;
  classification: ConversationClassification | null;
  classified_at: string | null;
  classified_by_model: string | null;
  created_at: string;
}

// ============================================
// types/analytics.types.ts
// ============================================

export interface ConversationStats {
  totalSessions: number;
  totalMessages: number;
  classifiedCount: number;
  unclassifiedCount: number;
  resolvedCount: number;

  // Alertas
  alerts: {
    frustrationCount: number;
    escalationNeeded: number;
    bugsReported: number;
  };

  // Top topics
  topTopics: Array<{
    topic: string;
    count: number;
    percentage: number;
  }>;

  // Distribución de calidad
  qualityDistribution: {
    high: number;
    medium: number;
    low: number;
    spam: number;
  };
}

export interface TopicPainPoint {
  topic: string;
  sessionCount: number;
  frustrationRate: number;      // 0-100
  unresolvedRate: number;       // 0-100
  highQualityRate: number;      // 0-100
  avgMessagesPerSession: number;
}

export interface ContentGap {
  topic: string;
  sessionCount: number;
  frustrationRate: number;
  resolutionRate: number;
  gapScore: number;
  recommendation: 'urgent' | 'recommended' | 'monitor' | 'ok';
}

export interface InterventionItem {
  session: ConversationSession;
  severity: 'critical' | 'high' | 'medium';
  flags: {
    frustration: boolean;
    escalation: boolean;
    bug: boolean;
  };
  hoursAgo: number;
}

// ============================================
// types/chat.types.ts
// ============================================

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export interface ChatState {
  messages: ChatMessage[];
  isLoading: boolean;
  isStreaming: boolean;
  error: string | null;
  conversationId: string | null;
}

export interface SendMessageParams {
  content: string;
  visitorId: string;
  conversationId?: string;
  visitorMetadata?: Record<string, unknown>;
}
```

---

## 4. LÓGICA DE NEGOCIO

### 4.1 Flujo de Chat (Core)

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUJO DE CHAT                                │
└─────────────────────────────────────────────────────────────────┘

Usuario escribe mensaje
        │
        ▼
┌───────────────────┐
│ Frontend envía    │
│ POST /api/chat    │
│ {content, visitorId, conversationId?}
└────────┬──────────┘
         │
         ▼
┌───────────────────┐     ┌─────────────────────┐
│ ¿Existe          │ NO  │ Crear conversación  │
│ conversationId?  │────►│ INSERT conversations│
└────────┬──────────┘     └──────────┬──────────┘
         │ SÍ                        │
         │◄──────────────────────────┘
         ▼
┌───────────────────┐
│ Guardar mensaje   │
│ del usuario       │
│ INSERT messages   │
└────────┬──────────┘
         │
         ▼
┌───────────────────┐
│ Obtener historial │
│ últimos 10 msgs   │
└────────┬──────────┘
         │
         ▼
┌───────────────────┐
│ Construir prompt  │
│ system + history  │
│ + user message    │
└────────┬──────────┘
         │
         ▼
┌───────────────────┐
│ Llamar OpenRouter │
│ con streaming     │
└────────┬──────────┘
         │
         ▼
┌───────────────────┐
│ Stream response   │◄──── Chunks se envían al frontend
│ al frontend       │       en tiempo real
└────────┬──────────┘
         │
         ▼ (onFinish)
┌───────────────────┐
│ Guardar respuesta │
│ INSERT messages   │
│ (role=assistant)  │
└───────────────────┘
```

---

## 5. SISTEMA DE CLASIFICACIÓN

### 5.1 Algoritmo de Agrupación de Sesiones

**Gap de 4 horas = nueva sesión**

Si hay más de 4 horas entre mensajes, se considera una nueva sesión de conversación.

### 5.2 Prompt de Clasificación

```
Analiza la conversación y responde SOLO con JSON:
{
  "topics": [array de topics de la lista permitida],
  "intent": "learning|troubleshooting|exploration|onboarding|feedback",
  "quality": "high|medium|low|spam",
  "summary": "Resumen de 1-2 oraciones",
  "flags": {
    "frustration_detected": boolean,
    "escalation_needed": boolean,
    "bug_reported": boolean,
    "resolved": boolean
  }
}

TOPICS DISPONIBLES: [cargados dinámicamente del agente]
```

### 5.3 Gap Score Algorithm

```
Gap Score = (sesiones × frustración) / resolución

- gapScore >= 50 → URGENTE
- gapScore >= 20 → RECOMENDADO
- gapScore >= 10 → MONITOREAR
- resto → OK
```

---

## 6. CHECKLIST DE IMPLEMENTACIÓN

### Fase 1: Chat Core (Actual)
- [x] Proyecto Next.js + TypeScript + Tailwind
- [x] Configuración OpenRouter
- [x] Endpoint /api/chat con streaming
- [x] Hook useChat
- [x] Componentes de chat (ChatWindow, MessageBubble, MessageInput)
- [x] Página principal con chat

### Fase 2: Persistencia (Próximo)
- [ ] Configurar cliente Supabase
- [ ] Crear tablas en Supabase (agents, conversations, messages)
- [ ] Guardar mensajes en BD
- [ ] Crear/obtener conversaciones

### Fase 3: Clasificación
- [ ] Crear tabla conversation_sessions
- [ ] Implementar agrupación por gap 4h
- [ ] Implementar clasificación con IA
- [ ] Endpoint /api/classify

### Fase 4: Analíticas
- [ ] Implementar cálculo de stats
- [ ] Implementar Pain Points
- [ ] Implementar Gap Score
- [ ] Implementar Intervention Queue
- [ ] Dashboard de analíticas

---

## 7. ARCHIVOS A CREAR

```
proyecto-agente/
├── src/
│   ├── app/
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── api/chat/route.ts
│   ├── features/chat/
│   │   ├── components/
│   │   │   ├── ChatWindow.tsx
│   │   │   ├── MessageBubble.tsx
│   │   │   ├── MessageInput.tsx
│   │   │   ├── TypingIndicator.tsx
│   │   │   └── index.ts
│   │   ├── hooks/useChat.ts
│   │   └── types/index.ts
│   └── shared/lib/
│       ├── openrouter.ts
│       └── supabase/
│           ├── client.ts
│           └── server.ts
├── package.json
├── tsconfig.json
├── tailwind.config.ts
├── postcss.config.mjs
├── next.config.ts
├── next-env.d.ts
├── .env.local
├── .mcp.json
└── SPECS.md
```
