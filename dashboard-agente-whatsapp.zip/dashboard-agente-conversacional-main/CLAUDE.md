# Chat Demo - Next.js + Supabase

Demo de aplicación de chat con IA usando Next.js y Supabase.

## Tech Stack

- **Framework**: Next.js 16 + React 19 + TypeScript
- **Backend**: Supabase (Auth + Database)
- **Estilos**: Tailwind CSS
- **AI**: Vercel AI SDK + OpenRouter

## Estructura del Proyecto

```
src/
├── app/                 # Next.js App Router
├── features/            # Features por funcionalidad
│   ├── auth/           # Autenticación
│   ├── chat/           # Chat con IA
│   └── dashboard/      # Dashboard
└── shared/             # Código reutilizable
    ├── components/     # Componentes UI
    ├── hooks/          # Hooks compartidos
    └── lib/            # Configuraciones (supabase, etc.)
```

## Comandos

```bash
npm run dev          # Servidor de desarrollo
npm run build        # Build producción
npm run lint         # ESLint
```

## Variables de Entorno

Copia `.env.local.example` a `.env.local` y configura:

- `NEXT_PUBLIC_SUPABASE_URL` - URL de tu proyecto Supabase
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` - Anon key de Supabase
- `OPENROUTER_API_KEY` - API key de OpenRouter
