-- Soporte WhatsApp: canal, deduplicación y unicidad de conversación por contacto.
-- Asume que ya existen las tablas conversations y messages.

alter table conversations
  add column if not exists channel text not null default 'web'
    check (channel in ('web', 'whatsapp'));

alter table conversations
  add column if not exists contact_name text;

alter table messages
  add column if not exists external_id text;

-- Meta reintenta webhooks: external_id (wamid) único evita procesar dos veces.
create unique index if not exists messages_external_id_key
  on messages (external_id) where external_id is not null;

-- Una conversación por (agente, contacto). visitor_id = 'wa_<número>' en WhatsApp.
create unique index if not exists conversations_agent_visitor_key
  on conversations (agent_id, visitor_id);

create index if not exists messages_conversation_created_idx
  on messages (conversation_id, created_at);
