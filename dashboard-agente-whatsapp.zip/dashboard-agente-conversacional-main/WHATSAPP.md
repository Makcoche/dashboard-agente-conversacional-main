# Conectar el agente a WhatsApp (Cloud API oficial de Meta)

## 1. Base de datos
Ejecuta `supabase/migrations/20261102_whatsapp.sql` en el SQL Editor de Supabase.

## 2. App en Meta
1. developers.facebook.com → Crear app → tipo **Business** → agregar el producto **WhatsApp**.
2. Vincula tu cuenta Meta Business.
3. En *WhatsApp → API Setup* Meta te da un **número de prueba** gratis (puedes escribir a hasta 5 números verificados). Úsalo para probar ya, sin tener número propio.
4. Copia el **Phone number ID** → `WHATSAPP_PHONE_NUMBER_ID`.
5. *Configuración de la app → Básica* → **App secret** → `WHATSAPP_APP_SECRET`.

## 3. Token permanente
El token temporal de API Setup dura 24 h. Para producción:
Business Settings → Users → **System users** → crear usuario (Admin) → asignar la app →
generar token con permisos `whatsapp_business_messaging` y `whatsapp_business_management`
→ `WHATSAPP_TOKEN`.

## 4. Desplegar en Vercel
Agrega TODAS las variables de `.env.local.example` en Vercel (Settings → Environment Variables) y despliega.
`SUPABASE_SERVICE_ROLE_KEY` está en Supabase → Project Settings → API. Es secreta.

## 5. Webhook
WhatsApp → **Configuration** → Webhook:
- Callback URL: `https://TU-APP.vercel.app/api/whatsapp/webhook`
- Verify token: el mismo valor de `WHATSAPP_VERIFY_TOKEN`
- Verificar y guardar, luego suscribirse al campo **messages**.

Prueba local: `ngrok http 3000` y usa esa URL temporalmente.

## 6. Número propio (producción)
- Debe poder recibir SMS o llamada y **no estar registrado en la app de WhatsApp** (o hay que borrarlo de ella).
- Agrégalo en *API Setup → Add phone number*, verifícalo y completa la verificación del negocio si Meta la pide.
- Actualiza `WHATSAPP_PHONE_NUMBER_ID` con el ID del nuevo número.

## Notas
- Solo se puede responder libremente dentro de 24 h desde el último mensaje del usuario; fuera de esa ventana hacen falta plantillas aprobadas (no implementado).
- Audios, imágenes, etc. reciben un aviso de que solo se entiende texto.
- Los mensajes duplicados que reenvía Meta se descartan por `messages.external_id`.
